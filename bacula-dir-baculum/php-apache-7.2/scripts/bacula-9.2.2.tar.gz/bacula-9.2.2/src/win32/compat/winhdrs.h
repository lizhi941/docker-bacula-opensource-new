
#ifndef __WINHDRS_H_
#define __WINHDRS_H_

#include "mingwconfig.h"
#include <winsock2.h>
#include <windows.h>
#include <mswsock.h>
#ifdef HAVE_IPV6
#include <ws2tcpip.h>
#endif
#include <psapi.h>

#endif
